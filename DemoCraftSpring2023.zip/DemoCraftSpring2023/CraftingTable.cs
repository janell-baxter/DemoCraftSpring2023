﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoCraftSpring2023
{
    public class CraftingTable
    {

        public CraftingTable()
        {

        }

        public Item Craft(Recipe recipe)
        {

            //code
            return new Item();
        }

        //example of return with no return type
        public void About()
        {

            return;
        }
    }
}